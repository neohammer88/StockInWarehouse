﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Move : Form
    {
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        DataTable dt = new DataTable();
        SqlConnection conn;
        SqlDataAdapter adapt;

        public Move()
        {
            InitializeComponent();
        }

        //Load column name for datagridview
        private void Form6_Load(object sender, EventArgs e)
        {
            lblUser.Text = Main.user;
            dt.Columns.Add("BMSNo");
            dt.Columns.Add("Location");
            dt.Columns.Add("Date");

            datePickerMove.Value = DateTime.Now;
            dataGridView6.DataSource = dt;
            this.dataGridView6.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        }

        //Move stocks from selected location to specific location
        private void btnMove1_Click(object sender, EventArgs e)
        {
            string user2 = lblUser.Text;
            //Check the locations
            if (string.IsNullOrEmpty(txtBoxFrom.Text) && string.IsNullOrEmpty(txtBoxTo.Text))
            {
                MessageBox.Show("Input Locations!", "ERROR", MessageBoxButtons.OK);
                return;
            }
            else
            {
                try
                {
                    string stateMove = "Move";
                    //Update location information of selected stocks
                    foreach (DataGridViewRow row in dataGridView6.Rows)
                    {
                        using (SqlConnection conn = new SqlConnection(connStr))
                        {
                            conn.Open();
                            using (SqlCommand cmd = new SqlCommand("INSERT INTO History (BMSNo, Location, Date, [User], State) VALUES (@bms, @location, @date, @user2, @state); UPDATE Stock SET Location = @location, Date = @date, [User] = @user2 WHERE BMSNo = '" + row.Cells[0].Value.ToString() + "'", conn))
                            {
                                //cmd.Parameters.AddWithValue("@id", txtId.Text);
                                cmd.Parameters.AddWithValue("@bms", (row.Cells["BMSNo"].Value));
                                cmd.Parameters.AddWithValue("@location", txtBoxTo.Text.ToString());
                                cmd.Parameters.AddWithValue("@date", datePickerMove.Value);
                                cmd.Parameters.AddWithValue("@user2", lblUser.Text.ToString());
                                cmd.Parameters.AddWithValue("@state", stateMove);
                                //if (!(string.IsNullOrEmpty(txtBmsNo3.Text)))
                                cmd.ExecuteNonQuery();
                                conn.Close();
                            }
                        }
                    }
                    MessageBox.Show("Move Success!", "MOVE", MessageBoxButtons.OK);
                    
                    //Show the updated location of stocks after moving
                    DataTable dt = new DataTable();
                    conn = new SqlConnection(connStr);
                    conn.Open();
                    adapt = new SqlDataAdapter("select * from Stock where Location like '" + txtBoxTo.Text + "%'", conn);
                    adapt.Fill(dt);
                    dataGridView6.DataSource = dt;
                    conn.Close();
                    txtBoxToSum_TextChanged(sender, e);
                    txtBoxFromSum_TextChanged(sender, e);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                    //txtBoxFrom.Text = "";
                    //txtBoxTo.Text = "";
                }
            }
        }

        //Show stocks which is going to move to another location
        private void txtBoxFrom_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                //                DataTable dt = new DataTable();
                conn = new SqlConnection(connStr);
                conn.Open();
                adapt = new SqlDataAdapter("select * from Stock where Location like '" + txtBoxFrom.Text + "%'", conn);
                adapt.Fill(dt);
                dataGridView6.DataSource = dt;
                conn.Close();
                txtBoxFromSum_TextChanged(sender, e);
            }
        }

        //Close Form6
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        //Close Form6 and show Form6 again
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.Hide();
            Move f6 = new Move();
            f6.Show();
            //dataGridView6.Rows.Clear();
            //dataGridView6.Refresh();
            //conn = new SqlConnection(connStr);
            //conn.Open();
            //DataTable dt = new DataTable();
            //BindingSource bs = new BindingSource();
            //bs.DataSource = dt;
//            dataGridView6.DataSource = dt;
            //conn.Close();
            //dataGridView6.Update();
            //dataGridView6.Refresh();
        }

        //Show the total number of which stocks is going to move to another location
        private void txtBoxFromSum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connStr);
                string sum = "SELECT COUNT(*) FROM Stock WHERE Location = '" + txtBoxFrom.Text + "'";
                SqlCommand cmd = new SqlCommand(sum, conn);
                conn.Open();
                object locationSum = cmd.ExecuteScalar();
                if (locationSum != null)
                    txtBoxFromSum.Text = locationSum.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        //Show the total number of stocks after moving
        private void txtBoxToSum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connStr);
                string sum = "SELECT COUNT(*) FROM Stock WHERE Location = '" + txtBoxTo.Text + "'";
                SqlCommand cmd = new SqlCommand(sum, conn);
                conn.Open();
                object locationSum = cmd.ExecuteScalar();
                if (locationSum != null)
                    txtBoxToSum.Text = locationSum.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
