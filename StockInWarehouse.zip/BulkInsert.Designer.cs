﻿namespace $safeprojectname$
{
    partial class BulkInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxTitle = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBmsNo9 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.datePicker9 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl9User = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBoxAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLocation9 = new System.Windows.Forms.TextBox();
            this.btn9SaveDB = new System.Windows.Forms.Button();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.btnCancel9 = new System.Windows.Forms.Button();
            this.btnStock9 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title";
            // 
            // txtBoxTitle
            // 
            this.txtBoxTitle.Location = new System.Drawing.Point(53, 71);
            this.txtBoxTitle.Name = "txtBoxTitle";
            this.txtBoxTitle.Size = new System.Drawing.Size(49, 21);
            this.txtBoxTitle.TabIndex = 1;
            this.txtBoxTitle.Text = "BMS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Starting No. (Without Title)";
            // 
            // txtBmsNo9
            // 
            this.txtBmsNo9.Location = new System.Drawing.Point(116, 71);
            this.txtBmsNo9.Name = "txtBmsNo9";
            this.txtBmsNo9.Size = new System.Drawing.Size(151, 21);
            this.txtBmsNo9.TabIndex = 3;
            this.txtBmsNo9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBmsNo9_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(453, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "Date :";
            // 
            // datePicker9
            // 
            this.datePicker9.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePicker9.Location = new System.Drawing.Point(455, 71);
            this.datePicker9.Name = "datePicker9";
            this.datePicker9.Size = new System.Drawing.Size(106, 21);
            this.datePicker9.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(604, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "User :";
            // 
            // lbl9User
            // 
            this.lbl9User.AutoSize = true;
            this.lbl9User.Location = new System.Drawing.Point(660, 27);
            this.lbl9User.Name = "lbl9User";
            this.lbl9User.Size = new System.Drawing.Size(0, 12);
            this.lbl9User.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(285, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "Amount";
            // 
            // txtBoxAmount
            // 
            this.txtBoxAmount.Location = new System.Drawing.Point(287, 71);
            this.txtBoxAmount.Name = "txtBoxAmount";
            this.txtBoxAmount.Size = new System.Drawing.Size(61, 21);
            this.txtBoxAmount.TabIndex = 9;
            this.txtBoxAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxAmount_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(372, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "Location";
            // 
            // txtLocation9
            // 
            this.txtLocation9.Location = new System.Drawing.Point(374, 71);
            this.txtLocation9.Name = "txtLocation9";
            this.txtLocation9.Size = new System.Drawing.Size(51, 21);
            this.txtLocation9.TabIndex = 11;
            this.txtLocation9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocation9_KeyPress);
            // 
            // btn9SaveDB
            // 
            this.btn9SaveDB.Location = new System.Drawing.Point(606, 72);
            this.btn9SaveDB.Name = "btn9SaveDB";
            this.btn9SaveDB.Size = new System.Drawing.Size(75, 23);
            this.btn9SaveDB.TabIndex = 12;
            this.btn9SaveDB.Text = "SAVE";
            this.btn9SaveDB.UseVisualStyleBackColor = true;
            this.btn9SaveDB.Click += new System.EventHandler(this.btn9SaveDB_Click);
            // 
            // dataGridView9
            // 
            this.dataGridView9.AllowUserToAddRows = false;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(53, 116);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.RowTemplate.Height = 23;
            this.dataGridView9.Size = new System.Drawing.Size(508, 251);
            this.dataGridView9.TabIndex = 13;
            // 
            // btnCancel9
            // 
            this.btnCancel9.Location = new System.Drawing.Point(606, 165);
            this.btnCancel9.Name = "btnCancel9";
            this.btnCancel9.Size = new System.Drawing.Size(75, 23);
            this.btnCancel9.TabIndex = 14;
            this.btnCancel9.Text = "CANCEL";
            this.btnCancel9.UseVisualStyleBackColor = true;
            this.btnCancel9.Click += new System.EventHandler(this.btnCancel9_Click);
            // 
            // btnStock9
            // 
            this.btnStock9.Location = new System.Drawing.Point(606, 116);
            this.btnStock9.Name = "btnStock9";
            this.btnStock9.Size = new System.Drawing.Size(75, 23);
            this.btnStock9.TabIndex = 15;
            this.btnStock9.Text = "INPUT";
            this.btnStock9.UseVisualStyleBackColor = true;
            this.btnStock9.Visible = false;
            this.btnStock9.Click += new System.EventHandler(this.btnStock9_Click);
            // 
            // BulkInsert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 400);
            this.Controls.Add(this.btnStock9);
            this.Controls.Add(this.btnCancel9);
            this.Controls.Add(this.dataGridView9);
            this.Controls.Add(this.btn9SaveDB);
            this.Controls.Add(this.txtLocation9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtBoxAmount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl9User);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.datePicker9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBmsNo9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBoxTitle);
            this.Controls.Add(this.label1);
            this.Name = "BulkInsert";
            this.Text = "BulkInsert";
            this.Load += new System.EventHandler(this.BulkInsert_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBmsNo9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker datePicker9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl9User;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBoxAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLocation9;
        private System.Windows.Forms.Button btn9SaveDB;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.Button btnCancel9;
        private System.Windows.Forms.Button btnStock9;
    }
}