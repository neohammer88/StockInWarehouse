﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Save : Form
    {
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        //SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        SqlDataReader rd;
        //DataTable dt = new DataTable();

        

        public Save()
        {
            InitializeComponent();
        }

        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //Decide names of datagridview column
        private void Form3_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connStr);
            string query = "SELECT Name FROM Member WHERE [Name] = @name";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            cmd.Parameters.AddWithValue("@name", lblUser.Text);

            lblUser.Text = Main.user;
            //dt.Columns.Add("BMSNo");
            //dt.Columns.Add("Location");
            //dt.Columns.Add("Date");
            //dt.Columns.Add("User");

            //dataGridView3.DataSource = dt;
            datePicker3.Value = DateTime.Now;
            this.ActiveControl = txtLocation3;
            //this.ActiveControl = txtBmsNo3;
            txtBoxSum_TextChanged(sender, e);
            conn.Close();
        }

        //Make strings to input information of each txt boxe to the data table
        private void btnStock_Click(object sender, EventArgs e)
        {
            string id = txtId3.Text;
            string bms = txtBmsNo3.Text;
            string location = txtLocation3.Text;
            string user2 = lblUser.Text;
            //string date = datePicker3.Text;
            //DateTime datePick = DateTime.ParseExact(date, "mm/dd/yyyy", null);

            try
            {
                    //DataRow dr = dt.NewRow();
                    //dr[0] = txtBmsNo3.Text;
                    //dr[1] = txtLocation3.Text;
                    //dr[2] = datePicker3.Text;
                    //dr[3] = lblUser.Text;

                if (string.IsNullOrEmpty(txtBmsNo3.Text))
                {
                    MessageBox.Show("Please Input BMS No.!", "ERROR", MessageBoxButtons.OK);
                    return;
                }
                else
                {
                    //dt.Rows.Add(dr);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
//                txtBmsNo3.Text = "";
            }
        }

        //Make the enter function for scanner
        private void txtBmsNo3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                btnStock_Click(sender, e);
                btnSaveDB_Click(sender, e);
                txtBoxSum_TextChanged(sender, e);
            }
        }

        //Close Form3
        private void btnCancel2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        //Save stock information
        private void btnSaveDB_Click(object sender, EventArgs e)
        {
            try
            {
                string stateUpdate = "Update";
                string stateInsert = "Save";
                //foreach (DataGridViewRow row in dataGridView3.Rows)
                //{
                    //using (SqlConnection conn = new SqlConnection(connStr))
                    //{
                    SqlConnection conn = new SqlConnection(connStr);
                        //Check the duplicate in database
                        SqlCommand exist = new SqlCommand("SELECT COUNT(*) FROM Stock WHERE ([BMSNo] = @bms)", conn);
                        exist.Parameters.AddWithValue("@bms", txtBmsNo3.Text);
                        conn.Open();
                        int userExist = (int)exist.ExecuteScalar();
                        //if there is the duplicate in database, update information of each stock
                        if (userExist > 0)
                        {
                            //System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                            //player.SoundLocation = @"C:\sample1.wav";
                            //player.Load();
                            //player.Play();
                            using (SqlCommand cmd = new SqlCommand("INSERT INTO History (BMSNo, Location, Date, [User], State) VALUES (@bms, @location, getdate(), @user2, @state); UPDATE Stock SET Location = @location, Date = getdate(), [User] = @user2 WHERE BMSNo = '" + txtBmsNo3.Text + "'", conn))
                            {
                                cmd.Parameters.AddWithValue("@bms", txtBmsNo3.Text);
                                cmd.Parameters.AddWithValue("@location", txtLocation3.Text);
                                cmd.Parameters.AddWithValue("@date", datePicker3.Text.ToString());
                                cmd.Parameters.AddWithValue("@user2", lblUser.Text.ToString());
                                cmd.Parameters.AddWithValue("@state", stateUpdate);

                                cmd.ExecuteNonQuery();
                                //dataGridView3.Rows.RemoveAt(row.Index);
                                conn.Close();
                            }
                            //txtBmsNo3.Text = "";
                        }

                        //if the stock is new, input it to database
                        else
                        {
                            using (SqlCommand cmd = new SqlCommand("INSERT INTO History (BMSNo, Location, Date, [User], State) VALUES (@bms, @location, getdate(), @user2, @state); INSERT INTO Stock (BMSNo, Location, Date, [User]) VALUES (@bms, @location, getdate(), @user2)", conn))
                            {
                                //if (row.Cells["BMSNo"].Value == null || row.Cells["Location"].Value == null || row.Cells["Date"].Value == null||row.Cells["User"].Value == null)
                                //{
                                //    row.Cells["BMSNo"].Value = DBNull.Value;
                                //    row.Cells["Location"].Value = DBNull.Value;
                                //    row.Cells["Date"].Value = DBNull.Value;
                                //    row.Cells["User"].Value = DBNull.Value;
                                //}
                                cmd.Parameters.AddWithValue("@bms", txtBmsNo3.Text);
                                cmd.Parameters.AddWithValue("@location", txtLocation3.Text);
                                cmd.Parameters.AddWithValue("@date", datePicker3.Text.ToString());
                                cmd.Parameters.AddWithValue("@user2", lblUser.Text.ToString());
                                cmd.Parameters.AddWithValue("@state", stateInsert);

                                cmd.ExecuteNonQuery();
                                //dataGridView3.Rows.RemoveAt(row.Index);
                                conn.Close();
                            }
                        }
                //}
                //}
                conn.Close();
//                MessageBox.Show("Save Success!", "SAVE", MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                txtBmsNo3.Text = "";
                //datePicker3.Value = DateTime.Now;
            }
        }

        //Show the total number of stocks in a specific location
        private void txtBoxSum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connStr);
                string sum = "SELECT COUNT(*) FROM Stock WHERE Location = '" + txtLocation3.Text + "'";
                SqlCommand cmd = new SqlCommand(sum, conn);
                conn.Open();
                object locationSum = cmd.ExecuteScalar();
                if (locationSum != null)
                    txtBoxSum.Text = locationSum.ToString();
                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Give the enter function for scanner
        private void txtLocation3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBoxSum_TextChanged(sender, e);
                this.ActiveControl = txtBmsNo3;
            }
        }

        //private void btnBulk_Click(object sender, EventArgs e)
        //{
        //    BulkInsert f9 = new BulkInsert();
        //    f9.Show();
        //}

    }
}
