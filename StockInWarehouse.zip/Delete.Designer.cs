﻿namespace $safeprojectname$
{
    partial class Delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBMSNo4 = new System.Windows.Forms.TextBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBoxAmount = new System.Windows.Forms.TextBox();
            this.datePickerDelete = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxLocationSum = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLocation1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDeselect = new System.Windows.Forms.Button();
            this.btnSearch4 = new System.Windows.Forms.Button();
            this.btnCancel4 = new System.Windows.Forms.Button();
            this.btnDelete4 = new System.Windows.Forms.Button();
            this.btnDeleteAll = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // txtBMSNo4
            // 
            this.txtBMSNo4.Location = new System.Drawing.Point(81, 29);
            this.txtBMSNo4.Name = "txtBMSNo4";
            this.txtBMSNo4.Size = new System.Drawing.Size(130, 21);
            this.txtBMSNo4.TabIndex = 0;
            this.txtBMSNo4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBMSNo4_KeyPress);
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(11, 32);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(64, 12);
            this.lbl4.TabIndex = 1;
            this.lbl4.Text = "BMS No. :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtBoxAmount);
            this.groupBox1.Controls.Add(this.datePickerDelete);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtBoxLocationSum);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtLocation1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnDeselect);
            this.groupBox1.Controls.Add(this.btnSearch4);
            this.groupBox1.Controls.Add(this.btnCancel4);
            this.groupBox1.Controls.Add(this.btnDelete4);
            this.groupBox1.Controls.Add(this.lbl4);
            this.groupBox1.Controls.Add(this.txtBMSNo4);
            this.groupBox1.Location = new System.Drawing.Point(39, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(275, 306);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stock Information";
            // 
            // txtBoxAmount
            // 
            this.txtBoxAmount.Location = new System.Drawing.Point(223, 29);
            this.txtBoxAmount.Name = "txtBoxAmount";
            this.txtBoxAmount.Size = new System.Drawing.Size(46, 21);
            this.txtBoxAmount.TabIndex = 29;
            this.txtBoxAmount.TextChanged += new System.EventHandler(this.txtBoxAmount_TextChanged);
            // 
            // datePickerDelete
            // 
            this.datePickerDelete.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datePickerDelete.Location = new System.Drawing.Point(50, 139);
            this.datePickerDelete.Name = "datePickerDelete";
            this.datePickerDelete.Size = new System.Drawing.Size(100, 21);
            this.datePickerDelete.TabIndex = 28;
            this.datePickerDelete.Value = new System.DateTime(2018, 7, 6, 0, 0, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 12);
            this.label3.TabIndex = 27;
            this.label3.Text = "Date";
            // 
            // txtBoxLocationSum
            // 
            this.txtBoxLocationSum.Location = new System.Drawing.Point(189, 95);
            this.txtBoxLocationSum.Name = "txtBoxLocationSum";
            this.txtBoxLocationSum.Size = new System.Drawing.Size(42, 21);
            this.txtBoxLocationSum.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "Total";
            // 
            // txtLocation1
            // 
            this.txtLocation1.Location = new System.Drawing.Point(81, 95);
            this.txtLocation1.Name = "txtLocation1";
            this.txtLocation1.Size = new System.Drawing.Size(90, 21);
            this.txtLocation1.TabIndex = 7;
            this.txtLocation1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "Location :";
            // 
            // btnDeselect
            // 
            this.btnDeselect.Location = new System.Drawing.Point(9, 212);
            this.btnDeselect.Name = "btnDeselect";
            this.btnDeselect.Size = new System.Drawing.Size(102, 30);
            this.btnDeselect.TabIndex = 5;
            this.btnDeselect.Text = "DESELECT";
            this.btnDeselect.UseVisualStyleBackColor = true;
            this.btnDeselect.Click += new System.EventHandler(this.btnDeselect_Click);
            // 
            // btnSearch4
            // 
            this.btnSearch4.Location = new System.Drawing.Point(6, 47);
            this.btnSearch4.Name = "btnSearch4";
            this.btnSearch4.Size = new System.Drawing.Size(62, 20);
            this.btnSearch4.TabIndex = 4;
            this.btnSearch4.Text = "SEARCH";
            this.btnSearch4.UseVisualStyleBackColor = true;
            this.btnSearch4.Visible = false;
            this.btnSearch4.Click += new System.EventHandler(this.btnSearch4_Click);
            // 
            // btnCancel4
            // 
            this.btnCancel4.Location = new System.Drawing.Point(153, 212);
            this.btnCancel4.Name = "btnCancel4";
            this.btnCancel4.Size = new System.Drawing.Size(87, 30);
            this.btnCancel4.TabIndex = 3;
            this.btnCancel4.Text = "CANCEL";
            this.btnCancel4.UseVisualStyleBackColor = true;
            this.btnCancel4.Click += new System.EventHandler(this.btnCancel4_Click);
            // 
            // btnDelete4
            // 
            this.btnDelete4.Location = new System.Drawing.Point(77, 259);
            this.btnDelete4.Name = "btnDelete4";
            this.btnDelete4.Size = new System.Drawing.Size(82, 30);
            this.btnDelete4.TabIndex = 2;
            this.btnDelete4.Text = "DELETE";
            this.btnDelete4.UseVisualStyleBackColor = true;
            this.btnDelete4.Click += new System.EventHandler(this.btnDelete4_Click);
            // 
            // btnDeleteAll
            // 
            this.btnDeleteAll.Location = new System.Drawing.Point(636, 25);
            this.btnDeleteAll.Name = "btnDeleteAll";
            this.btnDeleteAll.Size = new System.Drawing.Size(107, 30);
            this.btnDeleteAll.TabIndex = 8;
            this.btnDeleteAll.Text = "DELETE ALL";
            this.btnDeleteAll.UseVisualStyleBackColor = true;
            this.btnDeleteAll.Click += new System.EventHandler(this.btnDeleteAll_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(332, 66);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(595, 315);
            this.dataGridView4.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(339, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 12);
            this.label4.TabIndex = 38;
            this.label4.Text = "USER :";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Gulim", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblUser.Location = new System.Drawing.Point(390, 31);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 15);
            this.lblUser.TabIndex = 39;
            // 
            // Delete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 407);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDeleteAll);
            this.Name = "Delete";
            this.Text = "Delete";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBMSNo4;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCancel4;
        private System.Windows.Forms.Button btnDelete4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button btnSearch4;
        private System.Windows.Forms.Button btnDeselect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLocation1;
        private System.Windows.Forms.Button btnDeleteAll;
        private System.Windows.Forms.TextBox txtBoxLocationSum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker datePickerDelete;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox txtBoxAmount;
    }
}