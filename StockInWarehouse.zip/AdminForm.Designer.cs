﻿namespace $safeprojectname$
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdminCancel = new System.Windows.Forms.Button();
            this.btnAdminConfirm = new System.Windows.Forms.Button();
            this.txtBoxAdminPW = new System.Windows.Forms.TextBox();
            this.txtBoxAdminId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdminCancel
            // 
            this.btnAdminCancel.Location = new System.Drawing.Point(194, 185);
            this.btnAdminCancel.Name = "btnAdminCancel";
            this.btnAdminCancel.Size = new System.Drawing.Size(77, 38);
            this.btnAdminCancel.TabIndex = 11;
            this.btnAdminCancel.Text = "CANCEL";
            this.btnAdminCancel.UseVisualStyleBackColor = true;
            this.btnAdminCancel.Click += new System.EventHandler(this.btnAdminCancel_Click);
            // 
            // btnAdminConfirm
            // 
            this.btnAdminConfirm.Location = new System.Drawing.Point(90, 185);
            this.btnAdminConfirm.Name = "btnAdminConfirm";
            this.btnAdminConfirm.Size = new System.Drawing.Size(76, 38);
            this.btnAdminConfirm.TabIndex = 10;
            this.btnAdminConfirm.Text = "CONFIRM";
            this.btnAdminConfirm.UseVisualStyleBackColor = true;
            this.btnAdminConfirm.Click += new System.EventHandler(this.btnAdminConfirm_Click);
            // 
            // txtBoxAdminPW
            // 
            this.txtBoxAdminPW.Location = new System.Drawing.Point(171, 117);
            this.txtBoxAdminPW.Name = "txtBoxAdminPW";
            this.txtBoxAdminPW.PasswordChar = '*';
            this.txtBoxAdminPW.Size = new System.Drawing.Size(100, 21);
            this.txtBoxAdminPW.TabIndex = 9;
            // 
            // txtBoxAdminId
            // 
            this.txtBoxAdminId.Location = new System.Drawing.Point(171, 64);
            this.txtBoxAdminId.Name = "txtBoxAdminId";
            this.txtBoxAdminId.Size = new System.Drawing.Size(100, 21);
            this.txtBoxAdminId.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "PASSWORD :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(88, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "ADMIN ID :";
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 285);
            this.Controls.Add(this.btnAdminCancel);
            this.Controls.Add(this.btnAdminConfirm);
            this.Controls.Add(this.txtBoxAdminPW);
            this.Controls.Add(this.txtBoxAdminId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdminCancel;
        private System.Windows.Forms.Button btnAdminConfirm;
        private System.Windows.Forms.TextBox txtBoxAdminPW;
        private System.Windows.Forms.TextBox txtBoxAdminId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}