﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Search : Form
    {
        //Make DataTable, DataRow, DataSource, SqlConnection and SqlDataAdapter
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        SqlConnection conn;
        SqlDataAdapter adapt;
        DataTable dt;
        
        public Search()
        {
            InitializeComponent();
        }

        // This line of code loads data into the 'masterDataSet.Stock' table.
        private void Form2_Load(object sender, EventArgs e)
        {
            lblUser.Text = Main.user;
            conn = new SqlConnection(connStr);
            conn.Open();
            adapt = new SqlDataAdapter("select * from Stock", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dataGridView2.DataSource = dt;
            this.dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            conn.Close();
            this.ActiveControl = txtSearchBMS;
            txtBoxSum2_TextChanged(sender, e);
        }


        //Close Form2
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        //Input BMS No, and search the specific stocks
        private void txtSearchBMS_TextChanged_1(object sender, EventArgs e)
        {

        }


        //Get data from the database
        private DataSet GetData()
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            DataSet ds = new DataSet();
            string sql = "SELECT * FROM Stock";
            SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
            adapter.Fill(ds);
            conn.Close();

            return ds;
        }

        //Display all data to datagridview
        private void btnView2_Click(object sender, EventArgs e)
        {
            DataSet ds = GetData();
            dataGridView2.DataSource = ds.Tables[0];
        }

        //Show how many stocks in each location place
        private void txtBoxSum2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connStr);
                string sum = "SELECT COUNT(*) FROM Stock WHERE Location = '" + txtBoxLocation2.Text + "'";
                SqlCommand cmd = new SqlCommand(sum, conn);
                conn.Open();
                object locationSum = cmd.ExecuteScalar();
                if (locationSum != null)
                    txtBoxSum2.Text = locationSum.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        //To give enter function for scanner
        private void txtBoxLocation2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBoxSum2_TextChanged(sender, e);
            }
        }

        private void txtSearchBMS_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == '\r')
            {
                btnSearch_Click(sender, e);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(connStr);
                conn.Open();
                adapt = new SqlDataAdapter("select * from Stock where BMSNo = '" + txtSearchBMS.Text + "'", conn);
                dt = new DataTable();
                adapt.Fill(dt);
                dataGridView2.DataSource = dt;
                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                txtSearchBMS.Text = "";
            }

        }

        //private void btnDelete_Click(object sender, EventArgs e)
        //{
        //    string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        //    SqlConnection conn = new SqlConnection(connStr);


        //    string id = txtId2.Text;
        //    string bms = txtBmsNo2.Text;
        //    string location = txtLocation2.Text;
        //    string date = datePicker2.Text;

        //    string sql = "DELETE FROM Stock WHERE BMSNo=@bms";
        //    SqlCommand cmd = new SqlCommand(sql, conn);
        //    //cmd.Parameters.AddWithValue("@id", txtId.Text);
        //    cmd.Parameters.AddWithValue("@bms", txtBmsNo2.Text);
        //    //cmd.Parameters.AddWithValue("@location", txtLocation2.Text);
        //    //cmd.Parameters.AddWithValue("@date", datePicker2.Text);
        //    try
        //    {
        //        if (!(string.IsNullOrEmpty(txtBmsNo2.Text)))
        //            conn.Open();
        //        cmd.ExecuteNonQuery();
        //        MessageBox.Show("Delete Success!", "DELETE", MessageBoxButtons.OK);

        //        //this.dataGridView2.ClearSelection();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Please Select BMS No.!", "ERROR", MessageBoxButtons.OK);
        //    }
        //    finally
        //    {
        //        txtBmsNo2.Text = "";
        //        txtLocation2.Text = "";
        //        datePicker2.Value = DateTime.Now;
        //        conn.Close();
        //    }
        //}
    }
}
