﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Delete : Form
    {
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        DataTable dt = new DataTable();
        SqlConnection conn;
        SqlDataAdapter adapt;

        public Delete()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            lblUser.Text = Main.user;
            dt.Columns.Add("BMSNo");
            dt.Columns.Add("Location");
            dt.Columns.Add("Date");
            dt.Columns.Add("User");
//            dt.Columns.Add("State");

            datePickerDelete.Value = DateTime.Now;
            dataGridView4.DataSource = dt;
            this.dataGridView4.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        }

        //Search a stock in database
        private void btnSearch4_Click(object sender, EventArgs e)
        {
            string bms = txtBMSNo4.Text;

            //If there is no input BMS No in text box, show the error message
            if (string.IsNullOrEmpty(txtBMSNo4.Text))
            {
                MessageBox.Show("Please Input BMS No.!", "ERROR", MessageBoxButtons.OK);
                return;
            }
            else
            {
                //Check the double scan in the same datagridview
                for (int i = 0; i < dataGridView4.Rows.Count; i++)
                {
                    if (txtBMSNo4.Text == dataGridView4.Rows[i].Cells["BMSNo"].Value.ToString())
                    {
                        //System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                        //player.SoundLocation = @"C:\sample1.wav";
                        //player.Load();
                        //player.Play();
                        // MessageBox.Show(txtBMSNo4.Text + "\n is Double Scan!", "Warning", MessageBoxButtons.OK);
                        return;
                    }
                }
            }

            //Check the stock in database
            try
            {
                conn = new SqlConnection(connStr);
                string exist = "SELECT COUNT(*) FROM Stock WHERE BMSNo = '" + txtBMSNo4.Text + "'";
                SqlCommand cmd = new SqlCommand(exist, conn);
                conn.Open();
                int userExist = Convert.ToInt32(cmd.ExecuteScalar().ToString());
                //If the stock is in databse, show it to datagridview
                if (userExist > 0)
                {
                    adapt = new SqlDataAdapter("select * from Stock where BMSNo = '" + txtBMSNo4.Text + "'", conn);

                    adapt.Fill(dt);
                    dataGridView4.DataSource = dt;
                    conn.Close();
                }
                //If the stock is not in database, show the error message
                else
                {
                    //System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    //player.SoundLocation = @"C:\sample1.wav";
                    //player.Load();
                    //player.Play();
                    MessageBox.Show(txtBMSNo4.Text + "\n is Not in DB!", "Warning", MessageBoxButtons.OK);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                txtBMSNo4.Text = "";
                conn.Close();
            }
        }

        //Give the enter function for scanner
        private void txtBMSNo4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                btnSearch4_Click(sender, e);
                txtBoxAmount_TextChanged(sender, e);
            }
        }

        //Close Form4
        private void btnCancel4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        //Delete the stocks
        private void btnDelete4_Click(object sender, EventArgs e)
        {
            //If there is no stocks in datagridview 
            if (dataGridView4.Rows.Count == 0)
            {
                MessageBox.Show("Please Search Stocks first!", "ERROR", MessageBoxButtons.OK);
//                return;
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Do you really want to delete them?", "CONFIRM", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        string stateDelete = "Delete";
                        //Delete stocks in datagridview
                        foreach (DataGridViewRow row in dataGridView4.Rows)
                        {
                            using (SqlConnection conn = new SqlConnection(connStr))
                            {
                                using (SqlCommand cmd = new SqlCommand("INSERT INTO History (BMSNo, Location, Date, [User], State) VALUES (@bms, @location, getdate(), @user2, @state); DELETE FROM Stock WHERE BMSNo = '" + row.Cells[0].Value.ToString() + "'", conn))
                                {
                                    //cmd.Parameters.AddWithValue("@id", txtId.Text);
                                    cmd.Parameters.AddWithValue("@bms", (row.Cells["BMSNo"].Value));
                                    cmd.Parameters.AddWithValue("@location", (row.Cells["Location"].Value));
                                    cmd.Parameters.AddWithValue("@date", datePickerDelete.Text.ToString());
                                    cmd.Parameters.AddWithValue("@user2", lblUser.Text.ToString());
                                    cmd.Parameters.AddWithValue("@state", stateDelete);

                                    //if (!(string.IsNullOrEmpty(txtBmsNo3.Text)))
                                    conn.Open();
                                    cmd.ExecuteNonQuery();
                                    conn.Close();
                                }
                            }
                        }
                        MessageBox.Show("Delete Success!", "DELETE", MessageBoxButtons.OK);
                        btnCancel4_Click(sender, e);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        txtBMSNo4.Text = "";
                        conn.Close();
                    }

                }
                else if (dialogResult == DialogResult.No)
                {
                    return;
                }

            }
        }

        //Deselect stocks in datagridview in order not to delete, and erase it at datagridview
        private void btnDeselect_Click(object sender, EventArgs e)
        {
            if (dataGridView4.Rows.Count == 0)
            {
                MessageBox.Show("Please Search Stocks first!", "ERROR", MessageBoxButtons.OK);
//                return;
            }
            else
            {
                foreach (DataGridViewRow item in dataGridView4.SelectedRows)
                {
                    if (!item.IsNewRow)
                        dataGridView4.Rows.RemoveAt(item.Index);
                }
            }
        }

        //Show all stoks of selected location in DB to datagridview
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
//            DataTable dt = new DataTable();
            if (e.KeyChar == '\r')
            {
                conn = new SqlConnection(connStr);
                conn.Open();
                adapt = new SqlDataAdapter("select * from Stock where Location like '" + txtLocation1.Text + "%'", conn);
                adapt.Fill(dt);
                dataGridView4.DataSource = dt;
                conn.Close();
                txtBoxLocationSum_TextChanged(sender, e);
            }
        }

        //Show Form5 to delete all stocks in DB
        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm();
            admin.Show();
            //Login f5 = new Login();
            //f5.Show();
            //conn = new SqlConnection(connStr);
            //string delete = "DELETE * FROM Stock";
            //SqlCommand cmd = new SqlCommand(delete, conn);
            //conn.Open();
            //cmd.ExecuteNonQuery();
            //conn.Close();
            //MessageBox.Show("DELETE ALL");
        }

        //Show the total stock number in selected location
        private void txtBoxLocationSum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connStr);
                string sum = "SELECT COUNT(*) FROM Stock WHERE Location = '" + txtLocation1.Text + "'";
                SqlCommand cmd = new SqlCommand(sum, conn);
                conn.Open();
                object locationSum = cmd.ExecuteScalar();
                if (locationSum != null)
                    txtBoxLocationSum.Text = locationSum.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void txtBoxAmount_TextChanged(object sender, EventArgs e)
        {
            txtBoxAmount.Text = this.dataGridView4.Rows.Count.ToString();
        }
    }
}
