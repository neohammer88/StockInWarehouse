﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class History : Form
    {
        //Make DataTable, DataRow, DataSource, SqlConnection and SqlDataAdapter
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        SqlConnection conn;
        SqlDataAdapter adapt;
        DataTable dt;

        public History()
        {
            InitializeComponent();
        }

        private void History_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(connStr);
            conn.Open();
            adapt = new SqlDataAdapter("select * from History", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dgvHistory.DataSource = dt;
            this.dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            conn.Close();
            this.ActiveControl = txtSearchHistory;
        }

        private void btnHistoryCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void txtSearchHistory_TextChanged(object sender, EventArgs e)
        {
            conn = new SqlConnection(connStr);
            conn.Open();
            adapt = new SqlDataAdapter("select * from History where BMSNo like '" + txtSearchHistory.Text + "%'", conn);
            dt = new DataTable();
            adapt.Fill(dt);
            dgvHistory.DataSource = dt;
            conn.Close();
        }

        //Get data from the database
        private DataSet GetData()
        {
            //            string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            DataSet ds = new DataSet();
            string sql = "SELECT * FROM Stock";
            SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
            adapter.Fill(ds);
            conn.Close();

            return ds;
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            DataSet ds = GetData();
            dgvHistory.DataSource = ds.Tables[0];
        }

        private void btnDeleteHistory_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dialogResult = MessageBox.Show("Do you really want to delete History of the selected period?", "CONFIRM", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    //string date = dtpHistory.Text;
                    conn = new SqlConnection(connStr);
                    string delete = "DELETE FROM History Where [Date] BETWEEN @date AND @date2"/* + dtpHistory.Text + "'"*/;
                    SqlCommand cmd = new SqlCommand(delete, conn);
                    cmd.Parameters.AddWithValue("@date", dtpHistory.Value.Date);
                    cmd.Parameters.AddWithValue("@date2", dtpHistory2.Value.Date);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Delete History Succeed!");
                    this.Close();
                }
                else if(dialogResult == DialogResult.No)
                {
                    Application.Exit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
