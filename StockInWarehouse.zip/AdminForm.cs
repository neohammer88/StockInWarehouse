﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class AdminForm : Form
    {
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        DataTable dt = new DataTable();
        SqlConnection conn;
        SqlDataAdapter adapt;

        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAdminConfirm_Click(object sender, EventArgs e)
        {
            string admin, adminPassword;
            admin = txtBoxAdminId.Text;
            adminPassword = txtBoxAdminPW.Text;

            if (admin == "admin" && adminPassword == "admin")
            {
                DialogResult dialogResult = MessageBox.Show("Do you really want to delete all?", "CONFIRM", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    conn = new SqlConnection(connStr);
                    string delete = "DELETE FROM Stock";
                    SqlCommand cmd = new SqlCommand(delete, conn);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("DELETE ALL");
                    this.Close();
                }
                else if (dialogResult == DialogResult.No)
                {
                    Application.Exit();

                }
            }
            else
            {
                this.Hide();
                MessageBox.Show("WRONG USER!");
                Login f5 = new Login();
                f5.Show();
            }
        }

        private void btnAdminCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
