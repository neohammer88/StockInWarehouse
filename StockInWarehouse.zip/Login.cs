﻿/* Title : BMS Stock program
 * Version : 1.2
 * Language : C#
 * Programmer : Tom Rho
 * Date : 23/07/2018
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Login : Form
    {
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        DataTable dt = new DataTable();
        SqlConnection conn;
        SqlDataAdapter adapt;

        public Login()
        {
            InitializeComponent();
        }

        public static string user1;

        //Show login window to check the authority
        private void btnLogin_Click(object sender, EventArgs e)
        {
            user1 = txtBoxID.Text;

            try
            {
                string memberQuery = "SELECT * FROM Member WHERE [Name]= @member AND [Password]= @password"/* '" + txtBoxID.Text + "'"*/;
                SqlConnection conn = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand(memberQuery, conn);
                cmd.Parameters.AddWithValue("@member", txtBoxID.Text.ToString());
                cmd.Parameters.AddWithValue("@password", txtBoxPW.Text.ToString());
                //SqlDataReader dbr;
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    //MessageBox.Show("Welcome!");
                    this.Hide();
                    Main main = new Main();
                }
                else
                {
                    MessageBox.Show("Wrong User!");
                }
                conn.Close();
                //dbr = cmd.ExecuteReader();
                //int count = 0;
                //while (dbr.Read())
                //{
                //    count = count + 1;
                //}
                //if (count == 1)
                //{
                //    MessageBox.Show("Welcome!");
                //}
                //else if (count > 1)
                //{
                //    MessageBox.Show("Duplicate Name and PW");
                //}else
                //{
                //    MessageBox.Show("Wrong User");
                //    Application.Exit();
                //}
            }catch(Exception es)
            {
                MessageBox.Show(es.Message);
            }
            //finally
            //{
            //    conn.Close();
            //}
        }

        //Close Form5
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtBoxPW_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                btnLogin_Click(sender, e);
            }
        }
    }
}
