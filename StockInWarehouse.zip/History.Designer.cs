﻿namespace $safeprojectname$
{
    partial class History
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSearchHistory = new System.Windows.Forms.TextBox();
            this.lblHistory = new System.Windows.Forms.Label();
            this.dgvHistory = new System.Windows.Forms.DataGridView();
            this.btnHistory = new System.Windows.Forms.Button();
            this.btnHistoryCancel = new System.Windows.Forms.Button();
            this.dtpHistory = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDeleteHistory = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpHistory2 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearchHistory
            // 
            this.txtSearchHistory.Location = new System.Drawing.Point(114, 23);
            this.txtSearchHistory.Name = "txtSearchHistory";
            this.txtSearchHistory.Size = new System.Drawing.Size(137, 21);
            this.txtSearchHistory.TabIndex = 6;
            this.txtSearchHistory.TextChanged += new System.EventHandler(this.txtSearchHistory_TextChanged);
            // 
            // lblHistory
            // 
            this.lblHistory.AutoSize = true;
            this.lblHistory.Location = new System.Drawing.Point(37, 26);
            this.lblHistory.Name = "lblHistory";
            this.lblHistory.Size = new System.Drawing.Size(64, 12);
            this.lblHistory.TabIndex = 5;
            this.lblHistory.Text = "BMS No. :";
            // 
            // dgvHistory
            // 
            this.dgvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistory.Location = new System.Drawing.Point(39, 58);
            this.dgvHistory.Name = "dgvHistory";
            this.dgvHistory.RowTemplate.Height = 23;
            this.dgvHistory.Size = new System.Drawing.Size(638, 331);
            this.dgvHistory.TabIndex = 7;
            // 
            // btnHistory
            // 
            this.btnHistory.Location = new System.Drawing.Point(274, 21);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(75, 23);
            this.btnHistory.TabIndex = 8;
            this.btnHistory.Text = "Search";
            this.btnHistory.UseVisualStyleBackColor = true;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // btnHistoryCancel
            // 
            this.btnHistoryCancel.Location = new System.Drawing.Point(371, 21);
            this.btnHistoryCancel.Name = "btnHistoryCancel";
            this.btnHistoryCancel.Size = new System.Drawing.Size(75, 23);
            this.btnHistoryCancel.TabIndex = 9;
            this.btnHistoryCancel.Text = "Cancel";
            this.btnHistoryCancel.UseVisualStyleBackColor = true;
            this.btnHistoryCancel.Click += new System.EventHandler(this.btnHistoryCancel_Click);
            // 
            // dtpHistory
            // 
            this.dtpHistory.Font = new System.Drawing.Font("Gulim", 9F);
            this.dtpHistory.Location = new System.Drawing.Point(755, 105);
            this.dtpHistory.Name = "dtpHistory";
            this.dtpHistory.Size = new System.Drawing.Size(200, 21);
            this.dtpHistory.TabIndex = 10;
            this.dtpHistory.Value = new System.DateTime(2018, 9, 29, 19, 32, 32, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gulim", 9F);
            this.label1.Location = new System.Drawing.Point(753, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "Deleted From :";
            // 
            // btnDeleteHistory
            // 
            this.btnDeleteHistory.Font = new System.Drawing.Font("Gulim", 9F);
            this.btnDeleteHistory.Location = new System.Drawing.Point(808, 260);
            this.btnDeleteHistory.Name = "btnDeleteHistory";
            this.btnDeleteHistory.Size = new System.Drawing.Size(84, 33);
            this.btnDeleteHistory.TabIndex = 12;
            this.btnDeleteHistory.Text = "DELETE";
            this.btnDeleteHistory.UseVisualStyleBackColor = true;
            this.btnDeleteHistory.Click += new System.EventHandler(this.btnDeleteHistory_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gulim", 9F);
            this.label2.Location = new System.Drawing.Point(754, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "To :";
            // 
            // dtpHistory2
            // 
            this.dtpHistory2.Font = new System.Drawing.Font("Gulim", 9F);
            this.dtpHistory2.Location = new System.Drawing.Point(756, 189);
            this.dtpHistory2.Name = "dtpHistory2";
            this.dtpHistory2.Size = new System.Drawing.Size(200, 21);
            this.dtpHistory2.TabIndex = 13;
            this.dtpHistory2.Value = new System.DateTime(2018, 9, 29, 19, 32, 32, 0);
            // 
            // History
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 401);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpHistory2);
            this.Controls.Add(this.btnDeleteHistory);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpHistory);
            this.Controls.Add(this.btnHistoryCancel);
            this.Controls.Add(this.btnHistory);
            this.Controls.Add(this.dgvHistory);
            this.Controls.Add(this.txtSearchHistory);
            this.Controls.Add(this.lblHistory);
            this.Name = "History";
            this.Text = "History";
            this.Load += new System.EventHandler(this.History_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchHistory;
        private System.Windows.Forms.Label lblHistory;
        private System.Windows.Forms.DataGridView dgvHistory;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Button btnHistoryCancel;
        private System.Windows.Forms.DateTimePicker dtpHistory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDeleteHistory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpHistory2;
    }
}