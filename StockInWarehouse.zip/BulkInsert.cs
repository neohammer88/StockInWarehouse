﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace $safeprojectname$
{
    public partial class BulkInsert : Form
    {
        string connStr = "Data Source = (local); Initial Catalog = master; Integrated Security = true";
        DataTable dt = new DataTable();
        SqlConnection conn;

        public BulkInsert()
        {
            InitializeComponent();
        }

        private void BulkInsert_Load(object sender, EventArgs e)
        {
            lbl9User.Text = Main.user;
            dt.Columns.Add("BMSNo");
            dt.Columns.Add("Location");
            dt.Columns.Add("Date");
            dt.Columns.Add("User");

            dataGridView9.DataSource = dt;
            datePicker9.Value = DateTime.Now;
            this.ActiveControl = txtLocation9;
            this.dataGridView9.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;

        }

        private void btnCancel9_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnStock9_Click(object sender, EventArgs e)
        {
            string bms = txtBmsNo9.Text;
            string bmsNo = Regex.Replace(bms, @"\D", "");
            string location = txtLocation9.Text;
            string user2 = lbl9User.Text;

            try
            {
                if (string.IsNullOrEmpty(txtBmsNo9.Text))
                {
                    MessageBox.Show("Please Input BMS No.!", "ERROR", MessageBoxButtons.OK);
                    return;
                }
                else
                {
                    for (int i = 0; i < Convert.ToInt32(txtBoxAmount.Text); i++)
                    {
                        DataRow dr = dt.NewRow();
                        dr[0] = txtBoxTitle.Text.ToString() + (Convert.ToInt32(bmsNo) + (Convert.ToInt32(i)));
                        dr[1] = txtLocation9.Text;
                        dr[2] = datePicker9.Value.Date;
                        dr[3] = lbl9User.Text;
                        dt.Rows.Add(dr);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtBoxAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == '\r')
            {
                btnStock9_Click(sender, e);
            }
        }

        private void btn9SaveDB_Click(object sender, EventArgs e)
        {
            if(dataGridView9.Rows.Count == 0)
            {
                MessageBox.Show("Please Input Stocks first!", "ERROR", MessageBoxButtons.OK);
                return;
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Do you really want to save all stocks?", "CONFIRM", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        string stateUpdate = "Update";
                        string stateSave = "Save";

                        foreach (DataGridViewRow row in dataGridView9.Rows)
                        {
                            using (SqlConnection conn = new SqlConnection(connStr))
                            {
                                SqlCommand exist = new SqlCommand("SELECT COUNT(*) FROM Stock WHERE ([BMSNo] = @bms)", conn);
                                exist.Parameters.AddWithValue("@bms", (row.Cells["BMSNo"].Value));
                                conn.Open();
                                int userExist = (int)exist.ExecuteScalar();

                                if (userExist > 0)
                                {
                                    using (SqlCommand cmd = new SqlCommand("INSERT INTO History (BMSNo, Location, Date, [User], State) VALUES (@bms, @location, getdate(), @user2, @state); UPDATE Stock SET Location = @location, Date = getdate(), [User] = @user2 WHERE BMSNo = '" + txtBmsNo9.Text + "'", conn))
                                    {
                                        cmd.Parameters.AddWithValue("@bms", (row.Cells["BMSNo"].Value));
                                        cmd.Parameters.AddWithValue("@location", (row.Cells["Location"].Value));
                                        cmd.Parameters.AddWithValue("@user2", (row.Cells["User"].Value));
                                        cmd.Parameters.AddWithValue("@state", stateUpdate);

                                        //conn.Open();
                                        cmd.ExecuteNonQuery();
                                        conn.Close();
                                    }
                                }
                                else
                                {
                                    using (SqlCommand cmd = new SqlCommand("INSERT INTO History (BMSNo, Location, Date, [User], State) VALUES (@bms, @location, getdate(), @user2, @state); INSERT INTO Stock (BMSNo, Location, Date, [User]) VALUES (@bms, @location, getdate(), @user2)", conn))
                                    {
                                        cmd.Parameters.AddWithValue("@bms", (row.Cells["BMSNo"].Value));
                                        cmd.Parameters.AddWithValue("@location", (row.Cells["Location"].Value));
                                        cmd.Parameters.AddWithValue("@user2", (row.Cells["User"].Value));
                                        cmd.Parameters.AddWithValue("@state", stateSave);

                                        //conn.Open();
                                        cmd.ExecuteNonQuery();
                                        conn.Close();
                                    }
                                }
                                conn.Close();
                            }
                        }
                        MessageBox.Show("Save Success!", "SAVE", MessageBoxButtons.OK);
                        btnCancel9_Click(sender, e);
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    return;
                }
            }
        }

        private void txtLocation9_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBmsNo9.Focus();
            }
        }

        private void txtBmsNo9_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBoxAmount.Focus();
            }
        }
    }
}
