﻿namespace $safeprojectname$
{
    partial class Save
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBmsNo3 = new System.Windows.Forms.TextBox();
            this.txtLocation3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtId3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.btnStock = new System.Windows.Forms.Button();
            this.btnCancel2 = new System.Windows.Forms.Button();
            this.btnSaveDB = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxSum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnBulk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // datePicker3
            // 
            this.datePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datePicker3.Location = new System.Drawing.Point(89, 175);
            this.datePicker3.Name = "datePicker3";
            this.datePicker3.Size = new System.Drawing.Size(126, 21);
            this.datePicker3.TabIndex = 26;
            this.datePicker3.Value = new System.DateTime(2018, 7, 24, 19, 27, 43, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 12);
            this.label3.TabIndex = 25;
            this.label3.Text = "Date";
            // 
            // txtBmsNo3
            // 
            this.txtBmsNo3.Location = new System.Drawing.Point(89, 84);
            this.txtBmsNo3.Name = "txtBmsNo3";
            this.txtBmsNo3.Size = new System.Drawing.Size(126, 21);
            this.txtBmsNo3.TabIndex = 24;
            this.txtBmsNo3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBmsNo3_KeyPress);
            // 
            // txtLocation3
            // 
            this.txtLocation3.Location = new System.Drawing.Point(89, 133);
            this.txtLocation3.Name = "txtLocation3";
            this.txtLocation3.Size = new System.Drawing.Size(126, 21);
            this.txtLocation3.TabIndex = 23;
            this.txtLocation3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocation3_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 22;
            this.label6.Text = "Location";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 12);
            this.label5.TabIndex = 21;
            this.label5.Text = "BMS No.";
            // 
            // txtId3
            // 
            this.txtId3.Location = new System.Drawing.Point(119, 67);
            this.txtId3.Name = "txtId3";
            this.txtId3.Size = new System.Drawing.Size(126, 21);
            this.txtId3.TabIndex = 20;
            this.txtId3.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 12);
            this.label1.TabIndex = 19;
            this.label1.Text = "ID";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(361, 70);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(253, 32);
            this.dataGridView3.TabIndex = 27;
            this.dataGridView3.Visible = false;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnStock
            // 
            this.btnStock.Location = new System.Drawing.Point(529, 133);
            this.btnStock.Name = "btnStock";
            this.btnStock.Size = new System.Drawing.Size(85, 27);
            this.btnStock.TabIndex = 28;
            this.btnStock.Text = "INPUT";
            this.btnStock.UseVisualStyleBackColor = true;
            this.btnStock.Visible = false;
            this.btnStock.Click += new System.EventHandler(this.btnStock_Click);
            // 
            // btnCancel2
            // 
            this.btnCancel2.Location = new System.Drawing.Point(90, 280);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(88, 27);
            this.btnCancel2.TabIndex = 29;
            this.btnCancel2.Text = "CANCEL";
            this.btnCancel2.UseVisualStyleBackColor = true;
            this.btnCancel2.Click += new System.EventHandler(this.btnCancel2_Click);
            // 
            // btnSaveDB
            // 
            this.btnSaveDB.Location = new System.Drawing.Point(529, 166);
            this.btnSaveDB.Name = "btnSaveDB";
            this.btnSaveDB.Size = new System.Drawing.Size(85, 27);
            this.btnSaveDB.TabIndex = 31;
            this.btnSaveDB.Text = "SAVE";
            this.btnSaveDB.UseVisualStyleBackColor = true;
            this.btnSaveDB.Visible = false;
            this.btnSaveDB.Click += new System.EventHandler(this.btnSaveDB_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.datePicker3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtLocation3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtBmsNo3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(30, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(323, 218);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stock Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(280, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 33;
            this.label2.Text = "Total";
            // 
            // txtBoxSum
            // 
            this.txtBoxSum.Location = new System.Drawing.Point(270, 163);
            this.txtBoxSum.Name = "txtBoxSum";
            this.txtBoxSum.Size = new System.Drawing.Size(73, 21);
            this.txtBoxSum.TabIndex = 34;
            this.txtBoxSum.TextChanged += new System.EventHandler(this.txtBoxSum_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(359, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 12);
            this.label4.TabIndex = 36;
            this.label4.Text = "USER :";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Gulim", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblUser.Location = new System.Drawing.Point(410, 30);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 15);
            this.lblUser.TabIndex = 37;
            // 
            // btnBulk
            // 
            this.btnBulk.Location = new System.Drawing.Point(223, 280);
            this.btnBulk.Name = "btnBulk";
            this.btnBulk.Size = new System.Drawing.Size(90, 27);
            this.btnBulk.TabIndex = 38;
            this.btnBulk.Text = "BULK";
            this.btnBulk.UseVisualStyleBackColor = true;
            this.btnBulk.Visible = false;
            // 
            // Save
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 401);
            this.Controls.Add(this.btnBulk);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBoxSum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSaveDB);
            this.Controls.Add(this.btnCancel2);
            this.Controls.Add(this.btnStock);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.txtId3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Save";
            this.Text = "Save";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker datePicker3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBmsNo3;
        private System.Windows.Forms.TextBox txtLocation3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtId3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button btnStock;
        private System.Windows.Forms.Button btnCancel2;
        private System.Windows.Forms.Button btnSaveDB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxSum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnBulk;
    }
}