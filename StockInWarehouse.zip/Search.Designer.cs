﻿namespace $safeprojectname$
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.stockBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSet = new $safeprojectname$.masterDataSet();
            this.btnCancel = new System.Windows.Forms.Button();
            this.stockTableAdapter = new $safeprojectname$.masterDataSetTableAdapters.StockTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearchBMS = new System.Windows.Forms.TextBox();
            this.btnView2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxLocation2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxSum2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(27, 48);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(755, 343);
            this.dataGridView2.TabIndex = 1;
            // 
            // stockBindingSource
            // 
            this.stockBindingSource.DataMember = "Stock";
            this.stockBindingSource.DataSource = this.masterDataSet;
            // 
            // masterDataSet
            // 
            this.masterDataSet.DataSetName = "masterDataSet";
            this.masterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(488, 12);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 29);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // stockTableAdapter
            // 
            this.stockTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "BMS No. :";
            // 
            // txtSearchBMS
            // 
            this.txtSearchBMS.Location = new System.Drawing.Point(102, 20);
            this.txtSearchBMS.Name = "txtSearchBMS";
            this.txtSearchBMS.Size = new System.Drawing.Size(137, 21);
            this.txtSearchBMS.TabIndex = 4;
            this.txtSearchBMS.TextChanged += new System.EventHandler(this.txtSearchBMS_TextChanged_1);
            this.txtSearchBMS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSearchBMS_KeyPress);
            // 
            // btnView2
            // 
            this.btnView2.Location = new System.Drawing.Point(824, 178);
            this.btnView2.Name = "btnView2";
            this.btnView2.Size = new System.Drawing.Size(81, 29);
            this.btnView2.TabIndex = 28;
            this.btnView2.Text = "VIEW";
            this.btnView2.UseVisualStyleBackColor = true;
            this.btnView2.Visible = false;
            this.btnView2.Click += new System.EventHandler(this.btnView2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(822, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 12);
            this.label2.TabIndex = 29;
            this.label2.Text = "Location :";
            this.label2.Visible = false;
            // 
            // txtBoxLocation2
            // 
            this.txtBoxLocation2.Location = new System.Drawing.Point(890, 101);
            this.txtBoxLocation2.Name = "txtBoxLocation2";
            this.txtBoxLocation2.Size = new System.Drawing.Size(48, 21);
            this.txtBoxLocation2.TabIndex = 30;
            this.txtBoxLocation2.Text = "A1";
            this.txtBoxLocation2.Visible = false;
            this.txtBoxLocation2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxLocation2_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(824, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 31;
            this.label3.Text = "Total :";
            this.label3.Visible = false;
            // 
            // txtBoxSum2
            // 
            this.txtBoxSum2.Location = new System.Drawing.Point(890, 140);
            this.txtBoxSum2.Name = "txtBoxSum2";
            this.txtBoxSum2.Size = new System.Drawing.Size(48, 21);
            this.txtBoxSum2.TabIndex = 32;
            this.txtBoxSum2.Visible = false;
            this.txtBoxSum2.TextChanged += new System.EventHandler(this.txtBoxSum2_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(389, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 12);
            this.label4.TabIndex = 40;
            this.label4.Text = "USER :";
            this.label4.Visible = false;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Gulim", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblUser.Location = new System.Drawing.Point(453, 20);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 15);
            this.lblUser.TabIndex = 41;
            this.lblUser.Visible = false;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(263, 18);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 42;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Visible = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 403);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBoxSum2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBoxLocation2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnView2);
            this.Controls.Add(this.txtSearchBMS);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.dataGridView2);
            this.Name = "Search";
            this.Text = "Search";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnCancel;
        private masterDataSet masterDataSet;
        private System.Windows.Forms.BindingSource stockBindingSource;
        private masterDataSetTableAdapters.StockTableAdapter stockTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearchBMS;
        private System.Windows.Forms.Button btnView2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxLocation2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxSum2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnSearch;
    }
}